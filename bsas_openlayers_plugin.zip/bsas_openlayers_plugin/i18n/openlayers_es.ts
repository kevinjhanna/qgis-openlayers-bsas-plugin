<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="es">
<context>
    <name>Form</name>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="72"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="73"/>
        <source>Enable map</source>
        <translation>Activa mapa</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="74"/>
        <source>Add map</source>
        <translation>Añadir mapa</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="75"/>
        <source>Hide cross in map</source>
        <translation>Ocultar cruz en mapa</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="76"/>
        <source>Refresh map</source>
        <translation>Actualizar mapa</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="77"/>
        <source>Save this image</source>
        <translation>Salvar esta imagen</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="78"/>
        <source>Copy rectangle (KML) of map to clipboard</source>
        <translation>Copiar rectángulo (KML) del mapa al portapapeles</translation>
    </message>
</context>
<context>
    <name>OpenLayersOverviewWidget</name>
    <message>
        <location filename="openlayers_ovwidget.py" line="235"/>
        <source>Save image</source>
        <translation>Salvar imagen</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="235"/>
        <source>Image(*.jpg)</source>
        <translation>Imagen(*.jpg)</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="248"/>
        <source>OpenLayers Overview</source>
        <translation>Menú OpenLayers</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="158"/>
        <source>At least one layer in map canvas required</source>
        <translation>Se requiere al menos una capa en el escritorio</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="248"/>
        <source>Error loading page!</source>
        <translation>¡Error leyendo página!</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="258"/>
        <source>Loading %1...</source>
        <translation>Leyendo %1...</translation>
    </message>
</context>
<context>
    <name>OpenlayersPlugin</name>
    <message>
        <location filename="openlayers_plugin.py" line="144"/>
        <source>OpenLayers Overview</source>
        <translation>Menú OpenLayers</translation>
    </message>
    <message>
        <location filename="openlayers_plugin.py" line="154"/>
        <source>Add %1 layer</source>
        <translation>Añadir %1 capa</translation>
    </message>
    <message>
        <location filename="openlayers_plugin.py" line="161"/>
        <source>Could not set Google projection!</source>
        <translation>¡Imposible establecer proyección de Google!</translation>
    </message>
</context>
</TS>
