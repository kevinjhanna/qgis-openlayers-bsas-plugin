# First time

1. ```brew install pyqt```
2. Move this folder into ~/.qgis2/python/plugins/

# Compile
3. make clean && make compile



    
