## For devs

1. ```brew install pyqt``` (in macOs)
2. Move this folder into ~/.qgis2/python/plugins/

# Compile
1. make clean && make compile

# Deploy
1. make package VERSION=<sha-1 del commit>
